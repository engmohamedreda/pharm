<?php
require_once ("../lib/loader.php");
if(!isSignedIn("customer")){
    redirect("../");
    return;
}
global $activeUser;
$type = get("type");
?>
<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>

		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<!-- mobile metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="viewport" content="initial-scale=1, maximum-scale=1">
		<!-- site metas -->
		<title>system</title>
		<meta name="keywords" content="">
		<meta name="description" content="">
		<meta name="author" content="">
		<!-- bootstrap css -->
		<link rel="stylesheet" href="../css/bootstrap.min.css">
		<!-- style css -->
		<link rel="stylesheet" href="../css/style.css">
		<!-- Responsive-->
		<link rel="stylesheet" href="../css/responsive.css">
		<!-- fevicon -->
		<link rel="icon" href="../images/fevicon.png" type="image/gif" />
		<!-- Scrollbar Custom CSS -->
		<link rel="stylesheet" href="../css/jquery.mCustomScrollbar.min.css">
		<!-- Tweaks for older IEs-->
        <link href="../css/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
		<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
	</head>
    <body>

    <?php
        include ("header.php");
    ?>

    <div class="content">
        <div class="row">
            <div class="col-12">
                <a href="./" class="btn btn-danger full-width btn-lg"> رجوع </a>
                <hr>
                <h1 class="page-title">ارسال شكوى</h1>
                <?php
                if(set("activate")){

                    if(empty(post("complaint"))){
                        getMessage("البيانات غير صحيحة");
                    }else{
                        $data = [
                            "complaint" => post("complaint"),
                            "time" => time(),
                            "customer" => $activeUser["id"]
                        ];
                        $query = new MySQLQuery();
                        if(!$query->insert("complaint", $data)){
                            getMessage("خطأ");
                        }else{
                            getMessage("تم تقديم الشكوى", "success");
                        }
                    }
                }
                ?>
                <form method="post" action="" class="data-form">
                    <label>الشكوى</label>
                    <textarea type="text" class="form-control" name="complaint"></textarea>
                    <button class="btn" name="activate" type="submit">ارسال</button>
                </form>
            </div>
        </div>
    </div>

		<!-- Scripts -->
		<!-- end footer -->
		<!-- Javascript files-->
		<script src="../js/jquery.min.js"></script>
		<script src="../js/popper.min.js"></script>
		<script src="../js/bootstrap.bundle.min.js"></script>
		<script src="../js/jquery-3.0.0.min.js"></script>
		<script src="../js/plugin.js"></script>
		<!-- sidebar -->
		<script src="../js/jquery.mCustomScrollbar.concat.min.js"></script>
		<script src="../js/custom.js"></script>
	</body>
</html>
