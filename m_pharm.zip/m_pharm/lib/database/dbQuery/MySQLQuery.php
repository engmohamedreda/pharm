<?php

/*/
 *************************************************
 * @author  : Abdelwahab Taha (eng.abdelwahab.taha@gmail.com)
 * @version : 1.0
 * @since   : PHP 6.8
 *************************************************
/*/

class MySQLQuery extends QuickQuery{

    public function __construct($sql = null){
        parent::__construct($sql);
    }

    public function __destruct(){
        parent::__destruct();
    }

    // get database version
    public function version(){
        $this->sql("select version()");
        return $this->execute();
    }

    // get database tables
    public function tables(){
        $this->sql("show tables");
        return $this->execute();
    }

    // create table (table name , columns array( array(col1,data type, length, is_null, (optional) as_defined = val) , array(col2))
    // cols array (string , string , int , boolean)
    public function createTable($table, $colsArray = []){

        $createCode = "";

        for($i = 0; $i < count($colsArray); $i++){

            if($i) $createCode .= ", ";

            $colsCount = count($colsArray[$i]);

            if($colsCount != 4 && $colsCount != 5){
                $this->error = "column array must have 4 values at least ( col name , col type , length , is_null->(1{true} or 0{false}) )";
                $this->close();
                return false;
            }

            $x = 0;

            foreach($colsArray[$i] as $col){
                switch($x){
                    case 0:
                        $createCode .= "`" . $col . "` ";
                        break;
                    case 1:
                        $createCode .= $col;
                        break;
                    case 2:
                        $createCode .= is_numeric($col) ? "(".$col.") " : " ";
                        break;
                    case 3:
                        $createCode .= $col ? "NULL" : "NOT NULL";
                        break;
                }
                $x++;
            }

            if(isset($colsArray[$i][4])){
                $createCode .= " DEFAULT '" . $colsArray[$i][4] . "'";
            }

        }

        $this->sql("CREATE TABLE `" . $table . "`(" . $createCode . ") ENGINE = InnoDB");
        return $this->execute();

    }

    // check if table exists
    public function tableExists($table){

        $this->sql("SHOW TABLES LIKE '".$table."'");
        $this->execute();

        $schema = parent::results();

        return is_array($schema) && count($schema);

    }

    // create table (table name)
    public function removeTable($table){

        if(!$this->tableExists($table)){
            $this->error = "table not exists!";
            return false;
        }

        $this->sql("DROP TABLE `".$table."`");
        return $this->execute();

    }

    // add columns to table (table name , columns array( array(col1,data type, length, is_null, (optional) as_defined = val) , array(col2))
    // cols array (string , string , int , boolean)
    public function addColumns($table,$colsArray){

        $createCode = "";

        for($i = 0; $i < count($colsArray); $i++){

            if($i) $createCode .= ", ";

            $colsCount = count($colsArray[$i]);

            if($colsCount != 4 && $colsCount != 5){
                $this->error = "column array must have 4 values at least ( col name , col type , length , is_null->(1{true} or 0{false}) )";
                return false;
            }

            $x = 0;

            foreach($colsArray[$i] as $col){
                switch($x){
                    case 0:
                        $createCode .= "`" . $col . "` ";
                        break;
                    case 1:
                        if(!in_array(strtoupper($col), ConnectionSettings::dataTypes())){
                            $this->error = "unsupported data type";
                            return false;
                        }
                        $createCode .= $col;
                        break;
                    case 2:
                        $createCode .= "(".$col.") ";
                        break;
                    case 3:
                        $createCode .= $col ? "NULL" : "NOT NULL";
                        break;
                }

                $x++;
            }

            if(isset($colsArray[$i][4])){
                $createCode .= " DEFAULT '" . $colsArray[$i][4] . "'";
            }

        }

        $this->sql("ALTER TABLE `" . $table . "` ADD " . $createCode . "");
        return $this->execute();

    }

    // get table columns
    public function showColumns($table){

        if(!$this->tableExists($table)){
            $this->error = "table not exists!";
            return false;
        }

        $this->sql("SHOW COLUMNS FROM `" . $table . "`");
        return $this->execute();

    }

    // create table (table name, column name)
    public function removeColumn($table,$col){

        if(!$this->tableExists($table)){
            $this->error = "table not exists!";
            return false;
        }

        $this->sql("SHOW COLUMNS FROM `" . $table . "` WHERE Field = '" . $col . "'");
        $this->execute();

        $result = parent::results();

        if(!is_array($result) || !count($result)){
            $this->error = "column not exists!";
            return false;
        }

        $this->sql("ALTER TABLE `" . $table . "` DROP COLUMN `" . $col . "`");
        return $this->execute();

    }

    // edit table column(table name , column name , col new name , col new type , col new length , col new is_null)
    public function editColumns($table,$col,$name,$type,$length,$isNull){

        if(!in_array(strtoupper($type), ConnectionSettings::dataTypes())){
            $this->error = "unsupported data type";
            return false;
        }

        if(!$this->tableExists($table)){
            $this->error = "table not exists!";
            return false;
        }

        $this->sql("SHOW COLUMNS FROM `" . $table . "` WHERE Field = '" . $col . "'");
        $this->execute();

        $result = parent::results();

        if(!is_array($result) || !count($result)){
            $this->error = "column not exists!";
            return false;
        }

        $this->sql("SHOW COLUMNS FROM `" . $table . "` WHERE Field = '" . $name . "'");
        $this->execute();

        $result = parent::results();

        if(is_array($result) && count($result)){
            $this->error = "column name is already exists!";
            return false;
        }

        $createCode  = "`" . $name . "` ";
        $createCode .= $type;
        $createCode .= "(".$length.") ";
        $createCode .= $isNull ? "NULL" : "NOT NULL";

        $this->sql("ALTER TABLE `" . $table . "` CHANGE `" . $col . "` " . $createCode . "");
        return $this->execute();

    }

    // move column (table name , column name , after ( second column name )) set $after = null if you want column to be the first
    public function moveColumn($table,$col,$after = null){

        if(!$this->tableExists($table)){
            $this->error = "table not exists!";
            return false;
        }

        $this->sql("SHOW COLUMNS FROM `" . $table . "` WHERE Field = '" . $col . "'");
        $this->execute();

        $result = parent::results();

        if(!is_array($result) || !count($result)){
            $this->error = "column not exists!";
            return false;
        }

        $this->sql("SELECT DATA_TYPE , CHARACTER_MAXIMUM_LENGTH FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '" . $table . "' AND COLUMN_NAME = '" . $col . "'");
        $this->execute();

        $result = parent::results();

        if(!is_array($result) || !count($result)){
            $this->error = "column not exists!";
            return false;
        }

        foreach($result as $colx){

            $length = $colx['CHARACTER_MAXIMUM_LENGTH'];
            $type   = $colx['DATA_TYPE'];

        }

        $newLength = "(" . $length . ")";

        if($type != "VARCHAR" && $type != "varchar" && empty($length)) $newLength = null;

        if(!empty($after)){
            $this->sql("SHOW COLUMNS FROM `" . $table . "` WHERE Field = '" . $after . "'");
            $this->execute();
            $result = parent::results();

            if(!is_array($result) || !count($result)){
                $this->error = "column not exists!";
                return false;
            }

            $this->sql("ALTER TABLE `" . $table . "` CHANGE `" . $col . "` `" . $col . "` " . $type . $newLength . " AFTER `" . $after . "`");
        }else{
            $this->sql("ALTER TABLE `" . $table . "` CHANGE `" . $col . "` `" . $col . "` " . $type . $newLength . " FIRST");
        }

        return $this->execute();

    }

    // add primary key (table name , column name , set auto increment [true or false])
    public function addPrimary($table,$col,$autoIncrement = true){

        if(!$this->tableExists($table)){
            $this->error = "table not exists!";
            return false;
        }

        $this->sql("SHOW COLUMNS FROM `" . $table . "` WHERE Field = '" . $col . "'");
        $this->execute();

        $result = parent::results();

        if(!is_array($result) || !count($result)){
            $this->error = "column not exists!";
            return false;
        }

        if(!$this->execute()) return false;

        if($autoIncrement) $this->sql("ALTER TABLE `" . $table . "` MODIFY COLUMN `" . $col . "` ". $result[0]["Type"] ." AUTO_INCREMENT PRIMARY KEY");
        else $this->sql("ALTER TABLE `" . $table . "` ADD PRIMARY KEY (`" . $col . "`)");

        return $this->execute();

    }

    // remove table primary key (table name)
    public function removePrimary($table){

        if(!$this->tableExists($table)){
            $this->error = "table not exists!";
            return false;
        }

        $this->sql("ALTER TABLE `" . $table . "` DROP PRIMARY KEY");

        return $this->execute();

    }

    // add index(table name , column name)
    public function addIndex($table,$col){

        if(!$this->tableExists($table)){
            $this->error = "table not exists!";
            return false;
        }

        $this->sql("SHOW COLUMNS FROM `" . $table . "` WHERE Field = '" . $col . "'");
        $this->execute();

        $result = parent::results();

        if(!is_array($result) || !count($result)){
            $this->error = "column not exists!";
            return false;
        }

        $this->sql("ALTER TABLE `" . $table . "` ADD INDEX (`" . $col . "`)");

        return $this->execute();

    }

    // add unique(table name , column name)
    public function addUnique($table,$col){

        if(!$this->tableExists($table)){
            $this->error = "table not exists!";
            return false;
        }

        $this->sql("SHOW COLUMNS FROM `" . $table . "` WHERE Field = '" . $col . "'");
        $this->execute();

        $result = parent::results();

        if(!is_array($result) || !count($result)){
            $this->error = "column not exists!";
            return false;
        }

        $this->sql("ALTER TABLE `" . $table . "` ADD UNIQUE (`" . $col . "`)");

        return $this->execute();

    }

    // indexes(table name)
    public function indexes($table, $PK = false){

        if(!$this->tableExists($table)){
            $this->error = "table not exists!";
            return false;
        }

        if($PK) $this->sql("SHOW KEYS FROM `" . $table . "` WHERE Key_name = 'PRIMARY'");
        else $this->sql("SHOW KEYS FROM `" . $table . "`");

        return $this->execute();

    }

    // remove index(table name , column name)
    public function removeIndex($table,$col){

        if(!$this->tableExists($table)){
            $this->error = "table not exists!";
            return false;
        }

        $this->sql("SHOW COLUMNS FROM `" . $table . "` WHERE Field = '" . $col . "'");
        $this->execute();

        $result = parent::results();

        if(!is_array($result) || !count($result)){
            $this->error = "column not exists!";
            return false;
        }

        $this->sql("DROP INDEX `" . $col . "` ON `" . $table . "`");

        return $this->execute();

    }

    // create relationship (first table name , foreign key , second table name , primary key)
    public function addRelation($table1,$fk,$table2,$pk, $onUpdate = "CASCADE", $onDelete = "SET NULL"){

        if(!$this->tableExists($table1) || !$this->tableExists($table2)){
            $this->error = "table not exists!";
            return false;
        }

        $this->sql("SHOW COLUMNS FROM `" . $table1 . "` WHERE Field = '" . $fk . "'");
        $this->execute();

        $result = parent::results();

        if(!is_array($result) || !count($result)){
            $this->error = "column not exists!";
            return false;
        }

        $this->sql("SHOW COLUMNS FROM `" . $table2 . "` WHERE Field = '" . $pk . "'");

        $this->execute();

        $result = parent::results();

        if(!is_array($result) || !count($result)){
            $this->error = "column not exists!";
            return false;
        }

        $this->sql("ALTER TABLE `" . $table1 . "` ADD CONSTRAINT `fk_" . $fk . "_" . $table1 . "_" . $pk . "_" . $table2 . "` FOREIGN KEY (`" . $fk . "`) " .
            "REFERENCES `" . $table2 . "` (`" . $pk . "`) ON DELETE " . $onDelete . " ON UPDATE " . $onUpdate . "");

        return $this->execute();

    }

    // get constraint name (table name)
    public function getRelations($table){

        if(!$this->tableExists($table)){
            $this->error = "table not exists!";
            return false;
        }

        $this->sql("SELECT * FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE WHERE TABLE_NAME = '".$table."' AND CONSTRAINT_NAME <> 'PRIMARY'");

        return $this->execute();

    }

    // get constraint name (table name)
    public function getReferences($table){

        if(!$this->tableExists($table)){
            $this->error = "table not exists!";
            return false;
        }

        $this->sql("SELECT * FROM `INFORMATION_SCHEMA`.`KEY_COLUMN_USAGE` WHERE `REFERENCED_TABLE_SCHEMA` = ? AND `REFERENCED_TABLE_NAME` = ?");
        $this->value(DATABASE);
        $this->value($table);

        return $this->execute();

    }

    // remove relationship (table name, constraint name)
    public function removeRelation($table,$constraint){

        if(!$this->tableExists($table)){
            $this->error = "table not exists!";
            return false;
        }

        $this->sql("ALTER TABLE `" . $table . "` DROP FOREIGN KEY `" . $constraint . "`");

        return $this->execute();

    }

    // insert to database (table name, columns and values array = array('col' => 'value'))
    public function insert($table,$values){

        if(!$this->tableExists($table)){
            $this->error = "table not exists!";
            return false;
        }

        if(!is_array($values) || !count($values)){
            $this->error = "values should be an array";
            return false;
        }

        $columns = "(`". implode(array_keys($values) ,"`,`") . "`)";

        $vals = "";

        $values = array_values($values);
        $queryValues = [];

        if(is_array($values[0]) && isset($values[0][1])){
            for($i = 0; $i < count($values[0]); $i++){
                if($i) $vals .= ", ";
                $vals .= "(";
                for($x = 0; $x < count($values); $x++){
                    if(!isset($values[$x][$i])) continue;
                    if($x) $vals .= ", ";
                    $vals .= "?";
                    $queryValues[] = $values[$x][$i];
                }
                $vals .= ")";
            }
        }else{
            for($i = 0; $i < count($values); $i++){
                if($i) $vals .= ",";
                $vals .= "?";
                $queryValues[] = $values[$i];
            }
        }

        $vals = $vals[0] == "(" ? $vals : "(" . $vals . ")";

        $this->sql("INSERT INTO `" . $table . "` " . $columns . " VALUES " . $vals);
        $this->values($queryValues);

        return $this->execute();

    }

    // update database records (table name, columns and values array = array('col' => 'value'))
    public function update($table,$values){

        if(!$this->tableExists($table)){
            $this->error = "table not exists!";
            return false;
        }

        if(!is_array($values) || !count($values)){
            $this->error = "values should be an array";
            return false;
        }

        $vals = "";
        $queryValues = [];
        $i = 0;

        foreach($values as $key => $value){
            if($i) $vals .= " , ";
            $vals .= "`" . $key . "` = ?";
            $queryValues[] = $value;
            $i++;
        }

        if($this->where instanceof Where){
            $queryValues = array_merge($queryValues, $this->where->values());
            $vals .= $this->where->format();
        }

        $this->values($queryValues);

        $this->sql("UPDATE `" . $table . "` SET " . $vals);
        $this->where();

        return $this->execute();

    }

    // select database records (table name)
    public function select($table, $cols = [], $orderBy = [], $limit = 0, $startFrom = 0){

        if(!$this->tableExists($table)){
            $this->error = "table not exists!";
            return false;
        }

        if(is_array($cols) && count($cols)){
            $selected = "";
            for($i = 0; $i < count($cols); $i++){
                if($i){
                    $selected .= " ,";
                }
                $selected .= "`" . $cols[$i] . "`";
            }
        }else{
            $selected = "*";
        }

        $vals = "";

        if($this->where instanceof Where){
            $vals .= $this->where->format();
            $this->values($this->where->values());
        }

        if(count($orderBy)){
            $order = strtoupper(array_values($orderBy)[0]) == "DESC" ? "DESC" : "ASC";
            $col   = array_keys($orderBy)[0];
            $vals .= " ORDER BY `" . $col . "` " . $order;
        }

        $limit     = (int) $limit;
        $startFrom = (int) $startFrom;

        if($limit) $vals .= $startFrom ? " LIMIT " . $startFrom . " , " . $limit : " LIMIT " . $limit;

        $this->sql("SELECT " . $selected . " FROM `" . $table . "`" . $vals);
        $this->where();

        return $this->execute();

    }

    // Delete database records (table name)
    public function delete($table, $limit = 0){

        if(!$this->tableExists($table)){
            $this->error = "table not exists!";
            return false;
        }

        $vals = "";

        if($this->where instanceof Where){
            $vals .= $this->where->format();
            $this->values($this->where->values());
        }

        $limit = (int) $limit;

        if($limit) $vals .= " LIMIT " . $limit;

        $this->sql("DELETE FROM `" . $table . "` " . $vals);
        $this->where();

        return $this->execute();

    }

    // export database structure code // set $table as null if you want to export all tables
    public function export($createDB = false, $values = true, $table = null){

        $code = "";

        $code .= "-- ------------------------------------------" . "\n";
        $code .= "-- @author  : Abdelwahab Taha (eng.abdelwahab.taha@gmail.com)" . "\n";
        $code .= "-- @version : 1.0" . "\n";
        $code .= "-- ------------------------------------------" . "\n";
        $code .= "-- Database: " . DATABASE . "\n";
        $code .= "-- ------------------------------------------" . "\n";
        $code .= "\n";

        if($createDB){
            $code .= "CREATE DATABASE IF NOT EXISTS `" . DATABASE . "` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;" . "\n";
            $code .= "USE `" . DATABASE . "`;" . "\n";
            $code .= "\n";
        }

        if(!empty($table)){

        }

        $tables = $this->tables() ? $this->results() : [];

        $incrementedColumns = [];

        foreach($tables as $table){

            $code .= "-- -----------------------------" . "\n";
            $code .= "-- --Table: " . $table[0] . "\n";
            $code .= "-- -----------------------------" . "\n";
            $code .= "\n";
            $code .= "-- --Table structure Code----" . "\n";
            $code .= "CREATE TABLE IF NOT EXISTS `" . $table[0] . "`(" . "\n";

            $rows  = $this->showColumns($table[0]) ? $this->results() : [];

            for($i = 0; $i < count($rows); $i++){

                if($i) $code .= ", \n";
                $default = empty($rows[$i]["Default"]) ? "NULL" : $rows[$i]["Default"];
                $null    = $rows[$i]["Null"] == "NO" ? "NOT NULL" : "DEFAULT " . $default;
                $code   .= "\t`" . $rows[$i]["Field"] . "` " . $rows[$i]["Type"] . " " . $null;

                if($rows[$i]["Extra"] == "auto_increment"){
                    $incrementedColumns[$table[0]] = $rows[$i];
                }

            }

            $code .= "\n";
            $code .= ");";
            $code .= "\n";

            if($values){

                $vals  = $this->select($table[0]) ? $this->results("ASSOC") : [];
                $count = count($vals);

                if(!$count) continue;

                $code .= "\n";
                $cols  = array_keys($vals[0]);
                $code .= "-- --Table values Code----";
                $code .= "\n";
                $code .= "INSERT INTO `" . $table[0] . "` (`" . implode($cols ,"`,`") . "`) VALUES \n";

                for($i = 0; $i < $count; $i++){

                    $code .= "\t(";

                    for($x = 0; $x < count($cols); $x++){
                        if($x) $code .= ", ";
                        $code .= is_numeric($vals[$i][$cols[$x]]) ? $vals[$i][$cols[$x]] : "'" . $vals[$i][$cols[$x]] . "'";
                    }

                    $code .= ")";
                    $code .= $i + 1 == $count ? "; \n" : ", \n";

                }

            }

        }

        $code .= "\n";
        $code .= "-- -----------------------------" . "\n";
        $code .= "-- --------- Indexes -----------\n";
        $code .= "-- -----------------------------" . "\n";

        foreach($tables as $table){

            $vals  = $this->indexes($table[0]) ? $this->results() : [];
            $count = count($vals);

            if(!$count) continue;

            $code .= "\n";
            $code .= "-- -----------------------------" . "\n";
            $code .= "-- --Indexes for table: " . $table[0] . "\n";
            $code .= "-- -----------------------------" . "\n";
            $code .= "\n";

            $code .= "ALTER TABLE `" . $table[0] . "` \n\t";

            for($i = 0; $i < $count; $i++){
                if($i) $code .= ", ";
                $type  = $vals[$i]["Key_name"] == "PRIMARY" ? "PRIMARY KEY" : "KEY `" . $vals[$i]["Key_name"] . "`";
                $code .= "ADD " . $type . " (`" . $vals[$i]["Column_name"] . "`)";
            }
            $code .= ";\n";
        }

        $code .= "\n";
        $code .= "-- -----------------------------" . "\n";
        $code .= "-- ----- Auto increment --------\n";
        $code .= "-- -----------------------------" . "\n";

        foreach($tables as $table){

            $vals  = isset($incrementedColumns[$table[0]]) ? $incrementedColumns[$table[0]] : 0;
            $count = count($vals);

            if(!$count) continue;

            $code .= "\n";
            $code .= "-- -----------------------------" . "\n";
            $code .= "-- --Auto increment for table: " . $table[0] . "\n";
            $code .= "-- -----------------------------" . "\n";
            $code .= "\n";
            $code .= "ALTER TABLE `" . $table[0] . "` \n\t";

            $this->select($table[0], [$vals["Field"]], [$vals["Field"] => "desc"], 1);

            $lastIncrement = $this->rows() ? $this->results("assoc")[0][$vals["Field"]] : 0;

            $code .= "MODIFY `" . $vals["Field"] . "` " . $vals["Type"] . " NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=" . $lastIncrement . ";";
            $code .= "\n";

        }

        $code .= "\n";
        $code .= "-- -----------------------------" . "\n";
        $code .= "-- --------- Constraints -----------\n";
        $code .= "-- -----------------------------" . "\n";

        foreach($tables as $table){

            $vals  = $this->getRelations($table[0]) ? $this->results() : [];
            $count = count($vals);

            if(!$count) continue;

            $code .= "\n";
            $code .= "-- -----------------------------" . "\n";
            $code .= "-- --Constraints for table: " . $table[0] . "\n";
            $code .= "-- -----------------------------" . "\n";
            $code .= "\n";

            $code .= "ALTER TABLE `" . $table[0] . "` \n\t";

            for($i = 0; $i < $count; $i++){
                if($i) $code .= ", ";
                $code .= "ADD CONSTRAINT `" . $vals[$i]["CONSTRAINT_NAME"] . "` FOREIGN KEY (`" . $vals[$i]["COLUMN_NAME"] . "`) REFERENCES `" . $vals[$i]["REFERENCED_TABLE_NAME"] . "` (`" . $vals[$i]["REFERENCED_COLUMN_NAME"] . "`) ON DELETE CASCADE ON UPDATE CASCADE";
            }
            $code .= ";\n";
        }

        return $code;

    }

}