<?php
require_once ("lib/loader.php");
if(isSignedIn("admin")) redirect("admin");
if(isSignedIn("pharmacy")) redirect("pharmacy");
if(isSignedIn("customer")) redirect("customer");
?>
<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>

		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<!-- mobile metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="viewport" content="initial-scale=1, maximum-scale=1">
		<!-- site metas -->
		<title>system</title>
		<meta name="keywords" content="">
		<meta name="description" content="">
		<meta name="author" content="">
		<!-- bootstrap css -->
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<!-- style css -->
		<link rel="stylesheet" href="css/style.css">
		<!-- Responsive-->
		<link rel="stylesheet" href="css/responsive.css">
		<!-- fevicon -->
		<link rel="icon" href="images/fevicon.png" type="image/gif" />
		<!-- Scrollbar Custom CSS -->
		<link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
		<!-- Tweaks for older IEs-->
        <link href="css/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
		<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
	</head>
    <body>

		<header>
		 <div class="header-top">
			<div class="header">
			   <div class="container-fluid">
				  <div class="row">
					 <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
						<div class="full">
						   <div class="center-desk">
							  <div class="logo">
								 <a href="./"><img src="images/logo.png" style="height: 80px !important; width: auto;" alt="#" /></a>
							  </div>
						   </div>
						</div>
					 </div>
					 <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
						<div class="menu-area">
						   <div class="limit-box">
							  <nav class="main-menu">
								 <ul class="menu-area-main">
									<li class="active"> <a href="./">القائمة</a> </li>
									<li> <a href="sign.php">تسجيل الدخول</a> </li>
									<li> <a href="reg.php">تسجيل اول مره</a> </li>
								 </ul>
							  </nav>
						   </div>
						</div>
					 </div>
				  </div>
			   </div>
			</div>
			<!-- end header inner -->
			<!-- end header -->
			<section class="slider_section">
			   <div id="myCarousel" class="carousel slide banner_main" data-ride="carousel">
				  <ol class="carousel-indicators">
					 <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
					 <li data-target="#myCarousel" data-slide-to="1"></li>
				  </ol>
				  <div class="carousel-inner">
					 <div class="carousel-item active">
						<div class="container">
						   <div class="carousel-caption">
							  <div class="row ">
								 <div class="col-md-7">
									<div class="text-bg">
									   <span>نظام معلومات عن الصيدليات التابعة للتأمين الصحي</span> 
									   <h1> سجل الان </h1>
									   <p>
									   نظام معلومات يقوم بتسهيل الوصول الي أماكن الصيدليات التابعة للتأمين الصحي، و يحاول ان يساهم النظام في تطويرطرق التواصل مع هذه الصيدليات المختلفة لمعرفة حالة تواجد العقاقير ومعرفة أسعارها مما يخدم المرضي ويسهل عليهم عملية البحث عن العقاقير، حيث ان النظام يقوم بتلبية جميع احتياجات المستخدم، ويسهل عملية المقارنة بين العقاقير المختلفة ومعرفة افضل سعر وعنوان الصيدلية المختارة من المريض.
									   </p>
									   <a href="reg.php">التسجيل</a>
									</div>
								 </div>
							  </div>
						   </div>
						</div>
					 </div>
					 <div class="carousel-item">
						<div class="container">
						   <div class="carousel-caption">
							  <div class="row ">
								 <div class="col-md-7">
									<div class="text-bg">
									   <span>نظام معلومات عن الصيدليات التابعة للتأمين الصحي</span> 
									   <h1> سجل الان </h1>
									   <p>
									   نظام معلومات يقوم بتسهيل الوصول الي أماكن الصيدليات التابعة للتأمين الصحي، و يحاول ان يساهم النظام في تطويرطرق التواصل مع هذه الصيدليات المختلفة لمعرفة حالة تواجد العقاقير ومعرفة أسعارها مما يخدم المرضي ويسهل عليهم عملية البحث عن العقاقير، حيث ان النظام يقوم بتلبية جميع احتياجات المستخدم، ويسهل عملية المقارنة بين العقاقير المختلفة ومعرفة افضل سعر وعنوان الصيدلية المختارة من المريض.
									   </p>
									   <a href="reg.php">التسجيل</a>
									</div>
								 </div>
							  </div>
						   </div>
						</div>
					 </div>
					
				  </div>
				  <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
				  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
				  <span class="sr-only">Previous</span>
				  </a>
				  <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
				  <span class="carousel-control-next-icon" aria-hidden="true"></span>
				  <span class="sr-only">Next</span>
				  </a>
			   </div>
			</section>
		 </div>
		</header>

		<!-- Scripts -->
		<!-- end footer -->
		<!-- Javascript files-->
		<script src="js/jquery.min.js"></script>
		<script src="js/popper.min.js"></script>
		<script src="js/bootstrap.bundle.min.js"></script>
		<script src="js/jquery-3.0.0.min.js"></script>
		<script src="js/plugin.js"></script>
		<!-- sidebar -->
		<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
		<script src="js/custom.js"></script>
	</body>
</html>
