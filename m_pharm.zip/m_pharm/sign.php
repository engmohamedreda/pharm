<?php
    require_once ("lib/loader.php");
    if(isSignedIn("admin")) redirect("admin");
    if(isSignedIn("pharmacy")) redirect("pharmacy");
    if(isSignedIn("customer")) redirect("customer");
?>
<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>

		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<!-- mobile metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="viewport" content="initial-scale=1, maximum-scale=1">
		<!-- site metas -->
		<title>system</title>
		<meta name="keywords" content="">
		<meta name="description" content="">
		<meta name="author" content="">
		<!-- bootstrap css -->
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<!-- style css -->
		<link rel="stylesheet" href="css/style.css">
		<!-- Responsive-->
		<link rel="stylesheet" href="css/responsive.css">
		<!-- Scrollbar Custom CSS -->
		<link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
		<!-- Tweaks for older IEs-->
        <link href="css/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
		<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
	</head>
    <body>

		<header>
		 <div class="header-top">
			<div class="header">
			   <div class="container-fluid">
				  <div class="row">
					 <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
						<div class="full">
						   <div class="center-desk">
							  <div class="logo">
								 <a href="./"><img src="images/logo.png" style="height: 80px !important; width: auto;" alt="#" /></a>
							  </div>
						   </div>
						</div>
					 </div>
					 <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
						<div class="menu-area">
						   <div class="limit-box">
							  <nav class="main-menu">
								 <ul class="menu-area-main">
									<li class="active"> <a href="./">القائمة</a> </li>
									<li> <a href="sign.php">تسجيل الدخول</a> </li>
									<li> <a href="reg.php">تسجيل اول مره</a> </li>
								 </ul>
							  </nav>
						   </div>
						</div>
					 </div>
				  </div>
			   </div>
			</div>
		</header>

      <div class="contact">
         <div class="container-fluid">
            <div class="row">
               <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 padding-left1">
                  <div class="contact">
                     <div class="titlepage">
                        <h2>تسجيل الدخول</h2>
                         <?php
                            if(set("send")) signIn(post("email"), post("password"));
                         ?>
                     </div>
                     <form class="request" method="post" action="">
                        <div class="row">
                           <div class="col-sm-12">
                              <input class="contactus" placeholder="اسم المستخدم او رقم البطاقة التامينية" type="text" name="email">
                           </div>
                           <div class="col-sm-12">
                              <input class="contactus" placeholder="كلمة السر" type="password" name="password">
                           </div>
                           <div class="col-sm-12">
                              <button class="send" name="send" type="submit">تسجيل</button>
                           </div>
                        </div>
                     </form>
                  </div>
               </div>
            </div>
         </div>
      </div>
		</div>
		<!-- Scripts -->
		<!-- end footer -->
		<!-- Javascript files-->
		<script src="js/jquery.min.js"></script>
		<script src="js/popper.min.js"></script>
		<script src="js/bootstrap.bundle.min.js"></script>
		<script src="js/jquery-3.0.0.min.js"></script>
		<script src="js/plugin.js"></script>
		<!-- sidebar -->
		<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
		<script src="js/custom.js"></script>
	</body>
</html>
