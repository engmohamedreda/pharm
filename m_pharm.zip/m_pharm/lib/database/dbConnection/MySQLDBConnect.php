<?php

class MySQLDBConnect extends DBConnect{

    public function __construct(){
        parent::__construct();
    }

    public function __destruct(){
        parent::__destruct();
    }

    public function open(){

        try{
            $this->connect = new PDO("mysql:host=" . DB_SERVER . ";dbname=" . DATABASE, DB_SERVER_USERNAME, DB_SERVER_PASSWORD, $this->pdo_encode);
            $this->connect->setAttribute( PDO::ATTR_ERRMODE , PDO::ERRMODE_EXCEPTION );
            if(!$this->connect){
                $this->connect = null;
                $this->error   = "failed to open connection with the database server!";
                return false;
            }
        }catch(PDOException $ex){
            $this->connect = null;
            $this->error   = "failed to open connection with the database server! \n" . $ex->getMessage();
            return false;
        }

        return true;

    }

    public function close(){
        $this->connect = null;
    }

    public function test(){

        if(!defined("DB_SERVER") || empty(DB_SERVER)
            || !defined("DATABASE") || empty(DATABASE)
            || !defined("DB_SERVER_USERNAME") || empty(DB_SERVER_USERNAME)
            || !defined("DB_SERVER_PASSWORD")){
            $this->error = "please recheck the configuration file";
            return false;
        }

        try{
            $connect = new PDO("mysql:host=" . DB_SERVER . ";dbname=" . DATABASE, DB_SERVER_USERNAME, DB_SERVER_PASSWORD);
        }catch(PDOException $ex){
            $this->error = "failed to open connection with the database server! \n" . $ex->getMessage();
            return false;
        }finally{
            $connect = null;
        }

        return true;

    }

}