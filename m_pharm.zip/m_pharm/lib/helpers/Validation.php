<?php

class Validation{
	
	public static function Int($variable){
		return is_integer($variable);
	}

	public static function Number($variable){
		return is_numeric($variable);
	}

	public static function Float($string){
		return is_float($string);
	}

	public static function Double($string){
		return is_double($string);
	}

	public static function Name($string){
		return preg_match("/^[a-zA-Z\s]+$/",$string);
	}

	public static function Email($variable){
		return filter_var($variable, FILTER_VALIDATE_EMAIL);
	}
	
	public static function Phone($variable){
		return is_numeric($variable) && strlen($variable) > 10 && strlen($variable) < 13;
	}
	
	public static function Password($string){
		return strlen($string) >= 8 && preg_match("#[0-9]+#", $string) && preg_match("#[a-zA-Z]+#", $string);
	}

	public static function Date($string){
		return preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/",$string);
	}

	public static function Time($string){
		return preg_match("^(?:(?:([01]?\d|2[0-3]):)?([0-5]?\d):)?([0-5]?\d)$",$string);
	}

	public static function IPV4($string){
		return filter_var($string, FILTER_VALIDATE_IP);
	}	

	public static function IPV6($string){
		return filter_var($string, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6);
	}	

	public static function URL($string){
		return filter_var($string, FILTER_VALIDATE_URL);
	}	
	
	public static function Image($file){
		return in_array(mime_content_type($file), ['image/jpeg','image/png','image/bmp']);
	}

	public static function Archive($file){
		return in_array(mime_content_type($file), ['application/zip','application/x-rar-compressed','application/x-msdownload','application/vnd.ms-cab-compressed']);
	}
	
	public static function Media($file){
		return in_array(mime_content_type($file), ['audio/mpeg','application/vnd.lotus-1-2-3','video/3gpp2','video/3gpp','application/x-authorware-bin','audio/x-aac']);
	}

	public static function ZIP($file){
		return mime_content_type($file) == 'application/zip';
	}

	public static function Text($file){
		return mime_content_type($file) == 'text/plain';
	}

	public static function HTML($file){
		return mime_content_type($file) == 'text/html';
	}

	public static function CSS($file){
		return mime_content_type($file) == 'text/css';
	}

	public static function Javascript($file){
		return mime_content_type($file) == 'application/javascript';
	}

	public static function JSON($file){
		return mime_content_type($file) == 'application/json';
	}

	public static function XML($file){
		return mime_content_type($file) == 'application/xml';
	}

	public static function PDF($file){
		return mime_content_type($file) == 'application/pdf';
	}
	
	public static function OfficeWord($file){
		return mime_content_type($file) == 'application/msword';
	}

	public static function OfficeExcel($file){
		return mime_content_type($file) == 'application/vnd.ms-excel';
	}

	public static function OfficePowerPoint($file){
		return mime_content_type($file) == 'application/vnd.ms-powerpoint';
	}

	public static function SWF($file){
		return mime_content_type($file) == 'application/x-shockwave-flash';
	}

	public static function FLV($file){
		return mime_content_type($file) == 'video/x-flv';
	}

}
