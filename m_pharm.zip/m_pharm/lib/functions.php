<?php

/**
 * set cookies
 * @param string $key
 * @param string $value
 * @param bool $remember
 * @param string $path
 * @return string
 */
function set_cookie($key, $value, $remember = false, $path = "/"){

    if(session_status() != PHP_SESSION_NONE) session_destroy();

    $maxTime = 60 * 60 * 24;
    $remember ? session_set_cookie_params($maxTime, $path) : session_set_cookie_params( 24 * 60 * 60, $path);

    session_start();

    $data["value"] = $value;
    $data["time"] = time();
    $_SESSION[$key] = EncodingManager::stringEncode(serialize($data));

    return $data;

}

/**
 * get cookies
 * @param string $key
 * @return array|bool
 */
function get_cookie($key){
    if(session_status() == PHP_SESSION_NONE) session_start();
    if(!isset($_SESSION[$key])) return false;
    return @unserialize(EncodingManager::stringDecode($_SESSION[$key]));
}

function unset_cookies($key){
    if(session_status() == PHP_SESSION_NONE) session_start();
    if(!isset($_SESSION[$key])) return;
    $_SESSION[$key] = "";
    unset($_SESSION[$key]);
}

function set($key){
    return isset($_REQUEST[$key]);
}

function post($key){
    if(!isset($_POST[$key])) return null;
    if(is_array($_POST[$key])){
        $returns = [];
        foreach($_POST[$key] as $ar_key => $ar_val) $returns[$ar_key] = addslashes($ar_val);
        return $returns;
    }else return addslashes($_POST[$key]);
}

function files($key){
    return isset($_FILES[$key]['tmp_name']) ? $_FILES[$key] : null;
}

function get($key){
    return isset($_GET[$key]) ? addslashes($_GET[$key]) : null;
}

function redirect($path){
    header('location: ' . $path);
}

function refresh(){
    header("Refresh:0");
}

function getMessage($message, $type = "error"){

    $class = "alert alert-danger";

    switch ($type){
        case "error":
            $class = "alert alert-danger";
            break;
        case "success":
            $class = "alert alert-success";
            break;
        case "info":
            $class = "alert alert-info";
            break;
        case "warning":
            $class = "alert alert-warning";
            break;
    }

    echo '<div class="' . $class . ' text-right full-width">' . $message . '</div>';

}

function javaScript($order, $str = ""){

    switch ($order){
        case "refresh":
            echo '<script> window.location.reload(); </script>';
            break;
        case "refresh-no-params":
            echo '<script> window.location = location.protocol + "//" + location.host + location.pathname; </script>';
            break;
        case "go-to":
            echo '<script> window.location = "' . $str . '"; </script>';
            break;
    }

}
