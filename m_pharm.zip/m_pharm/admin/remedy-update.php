<?php
require_once ("../lib/loader.php");
if(!isSignedIn("admin")){
    redirect("../");
    return;
}
global $activeUser;

$id = get("id");
$query = new MySQLQuery();

$query->where(["id" => $id]);

if(!$query->select("remedy")){
    redirect("./");
    return;
}
if($query->rows() != 1){
    redirect("./");
    return;
}

$current = $query->results()[0];

?>
<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>

		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<!-- mobile metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="viewport" content="initial-scale=1, maximum-scale=1">
		<!-- site metas -->
		<title>system</title>
		<meta name="keywords" content="">
		<meta name="description" content="">
		<meta name="author" content="">
		<!-- bootstrap css -->
		<link rel="stylesheet" href="../css/bootstrap.min.css">
		<!-- style css -->
		<link rel="stylesheet" href="../css/style.css">
		<!-- Responsive-->
		<link rel="stylesheet" href="../css/responsive.css">
		<!-- fevicon -->
		<link rel="icon" href="../images/fevicon.png" type="image/gif" />
		<!-- Scrollbar Custom CSS -->
		<link rel="stylesheet" href="../css/jquery.mCustomScrollbar.min.css">
		<!-- Tweaks for older IEs-->
        <link href="../css/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
		<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
	</head>
    <body>

        <?php
            include ("header.php");
        ?>

        <div class="content">
            <div class="row">
                <div class="col-12">
                    <a href="remedy.php?id=<?= $current["id"] ?>" class="btn btn-danger full-width btn-lg"> رجوع </a>
                    <hr>
                    <h1 class="page-title"> <?= $current["name"] ?> </h1>
                    <?php
                    if(set("activate")){

                        if(empty(post("name")) || empty(post("details"))){
                            getMessage("البيانات غير صحيحة");
                        }else{

                            $passwordUpdate = false;
                            $location = null;

                            if(is_array(files("photo")) && isset(files("photo")["tmp_name"]) &&
                                !empty(files("photo")["tmp_name"])){

                                $photo = files("photo");

                                $extension = pathinfo($photo['name'], PATHINFO_EXTENSION);
                                $imageName = pathinfo($photo['name'], PATHINFO_FILENAME);

                                $location = $imageName . "." . $extension;

                                $glob = __DIR__ . "/../uploads/";

                                if(file_exists($glob . $location)){
                                    while(file_exists($glob . $location)){
                                        $location = uniqid() . "." . $extension;
                                    }
                                }

                                if(!move_uploaded_file($photo['tmp_name'], $glob . $location)){
                                    getMessage("خطأ فى التنفيذ");
                                }else  $passwordUpdate = true;

                            }

                            $query = new MySQLQuery();
                            $query->sql("SELECT `name` FROM `remedy` WHERE `name` = ? AND `id` <> ?");

                            $query->values([post("name"), $id]);

                            if(!$query->execute()){
                                getMessage("خطأ");
                            }else{
                                if($query->rows()){
                                    getMessage("الدواء مسجل مسبقا");
                                }else{

                                    $data = [
                                        "name" => post("name"),
                                        "details" => post("details"),
                                    ];

                                    if($passwordUpdate){
                                        $data["photo"] = $location;
                                        @unlink($glob . $current["photo"]);
                                    }

                                    $query->where(["id" => $current["id"]]);

                                    if(!$query->update("remedy", $data)){
                                        getMessage("خطأ");
                                    }else{
                                        getMessage("تم التعديل", "success");
                                        $query->where(["id" => $id]);
                                        if(!$query->select("remedy")) getMessage("خطأ");
                                        $current = $query->results()[0];
                                    }

                                }
                            }

                        }

                    }
                    ?>
                    <form method="post" action="" class="data-form" enctype="multipart/form-data">
                        <label>الاسم</label>
                        <input type="text" class="form-control" name="name" value="<?= $current["name"] ?>">
                        <label>الصورة</label>
                        <img src="../uploads/<?= $current["photo"] ?>" height="100">
                        <input type="file" class="form-control" name="photo">
                        <label>تفاصيل عن الدواء</label>
                        <textarea type="text" class="form-control" name="details"><?= $current["details"] ?></textarea>
                        <button class="btn" name="activate" type="submit">تعديل</button>
                    </form>
                </div>
            </div>
        </div>

		<!-- Scripts -->
		<!-- end footer -->
		<!-- Javascript files-->
		<script src="../js/jquery.min.js"></script>
		<script src="../js/popper.min.js"></script>
		<script src="../js/bootstrap.bundle.min.js"></script>
		<script src="../js/jquery-3.0.0.min.js"></script>
		<script src="../js/plugin.js"></script>
		<!-- sidebar -->
		<script src="../js/jquery.mCustomScrollbar.concat.min.js"></script>
		<script src="../js/custom.js"></script>
	</body>
</html>
