<?php

abstract class DBConnect{
	
	protected $connect = null;
	protected $error   = null;

	protected $pdo_encode = [PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"];

	public function __construct(){}
	
	public function __destruct(){
		$this->connect = null;
		$this->error   = null;
	}

	public abstract function open();
	
	public abstract function close();
	
	public abstract function test();
	
	public static function initialize(){
        if(!isset(DBSettings::SupportedDatabases()[DB_TYPE])){
            echo "database connection class is not exists please check your configuration file or reinstall lib";
            return null;
		}
		$class = DBSettings::SupportedDatabases()[DB_TYPE]["ConnectionClass"];
		return new $class();
	}
	
	public function error(){
		return $this->error;
	}
	
	public function connect(){
		return $this->connect;
	}
	
}