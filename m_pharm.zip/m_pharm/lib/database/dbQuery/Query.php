<?php

class Query{
	
	private $DB;
	private $statement;
	
	private $sql;
	private $results;
	
	private $resultsFetched = false;
	
	protected $values = [];
	protected $error  = null;
	
	public function __construct($sql = null){
        $this->DB = DBConnect::initialize();
        if($this->DB instanceof DBConnect) if($this->DB->open()) $this->sql = $sql;
	}
	
	public function __destruct(){
		$this->DB->close();
		$this->values = [];
		$this->statement = null;
	}
	
	public function sql($sql = null){
		if(empty($sql)) return $this->sql;
		$this->sql = $sql;
		return $this->sql;
	}
	
	public function values($values){
		if(!is_array($values)) return;
		$this->values = array_values($values);
	}
	
	public function value($value){
		$this->values[] = $value;
	}
	
	public function execute(){
		
		if(empty($this->DB->connect())){
			$this->error = "failed to connect database!";
			return false;
		}
		
		if(empty($this->sql)){
			$this->error = "cannot execute query (set sql query first)!";
			return false;
		}
		
		try{
			$this->statement = $this->DB->connect()->prepare($this->sql);
		}catch(PDOException $ex){
			$this->statement = null;
			$this->error = "cannot execute query! \n" . $ex->getMessage();
			return false;
		}
		
		try{
			if(count($this->values)){
				for($i = 0; $i < count($this->values); $i++){
					if(isset($this->values[$i]['tmp_name'])){
						$fopen = fopen($this->values[$i]['tmp_name'], 'rb');
						$this->statement->bindParam( ($i + 1) , $fopen , PDO::PARAM_LOB);
					}else{
						$this->statement->bindvalue( ($i + 1) , $this->values[$i]);
					}
				}
			}
		}catch(PDOException $ex){
			$this->statement = null;
			$this->error = "cannot execute query! \n" . $ex->getMessage();
			return false;
		}
		
		try{
			$this->statement->execute();
		}catch(PDOException $ex){
			$this->statement = null;
			$this->error = "cannot execute query! \n" . $ex->getMessage();
			return false;
		}finally{
			$this->values = [];
		}
		
		$this->resultsFetched = false;
		return true;
		
	}
	
	public function id(){
		return $this->DB->connect()->lastInsertId();
	}
	
	public function rows(){
		return !empty($this->statement) ? $this->statement->rowCount() : 0;
	}
	
	public function results($mod = "BOTH"){
		
		if($this->resultsFetched) return $this->results;
		
		$mod = strtoupper($mod);
		
		switch($mod){
			case "ASSOC":
				$style = PDO::FETCH_ASSOC;
				break;
			case "LAZY":
				$style = PDO::FETCH_LAZY;
				break;
			case "OBJ":
				$style = PDO::FETCH_OBJ;
				break;
			case "BOTH":
				$style = PDO::FETCH_BOTH;
				break;
			default:
				$style = PDO::FETCH_BOTH;
		}
		
		try{
			$this->results = !empty($this->statement) && $this->rows() ? $this->statement->fetchALL($style) : [];
		}catch(PDOException $ex){
			$this->error = "cannot fetch results! \n" . $ex->getMessage();
			return [];
		}
		
		$this->resultsFetched = true;
		return $this->results;
		
	}
	
	public function error(){
		return $this->error;
	}
	
}