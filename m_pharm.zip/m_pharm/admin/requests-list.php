<?php
require_once ("../lib/loader.php");
if(!isSignedIn("admin")){
    redirect("../");
    return;
}
global $activeUser;
?>
<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>

		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<!-- mobile metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="viewport" content="initial-scale=1, maximum-scale=1">
		<!-- site metas -->
		<title>system</title>
		<meta name="keywords" content="">
		<meta name="description" content="">
		<meta name="author" content="">
		<!-- bootstrap css -->
		<link rel="stylesheet" href="../css/bootstrap.min.css">
		<!-- style css -->
		<link rel="stylesheet" href="../css/style.css">
		<!-- Responsive-->
		<link rel="stylesheet" href="../css/responsive.css">
		<!-- fevicon -->
		<link rel="icon" href="../images/fevicon.png" type="image/gif" />
		<!-- Scrollbar Custom CSS -->
		<link rel="stylesheet" href="../css/jquery.mCustomScrollbar.min.css">
		<!-- Tweaks for older IEs-->
        <link href="../css/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
		<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
	</head>
    <body>

    <?php
        include ("header.php");
    ?>

    <div class="content">
        <div class="row">
            <div class="col-12">
                <a href="./" class="btn btn-danger full-width btn-lg"> رجوع </a>
                <hr>
                <h1 class="page-title"> عرض الطلبات </h1>
                <?php
                $query = new MySQLQuery();
                $query->select("request");
                if(!$query->rows()){
                    getMessage("لا توجد بيانات");
                }else{
                    ?>
                    <div class="table-responsive">
                        <table class="table ar table-bordered">
                            <tr>
                                <th>رقم</th>
                                <th>العميل</th>
                                <th>الصيدلية</th>
                                <th>تاريخ الارسال</th>
                                <th>عرض</th>
                            </tr>

                            <?php
                            $data = $query->results();
                            foreach ($data as $result){
                                $query->where(["id" => $result["customer"]]);
                                $query->select("customer");
                                $customer = $query->results()[0];
                                $query->where(["id" => $result["pharmacy"]]);
                                $query->select("pharmacy");
                                $pharmacy = $query->results()[0];
                                ?>
                                <tr>
                                    <td><?= $result["id"] ?></td>
                                    <td><?= $customer["name"] ?></td>
                                    <td><?= $pharmacy["name"] ?></td>
                                    <td><?= $result["date"] ?></td>
                                    <td>
                                        <a class="btn btn-success" href="request.php?id=<?= $result["id"]  ?>">
                                            <i class="fa fa-file"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php
                            }
                            ?>
                        </table>
                    </div>
                    <?php
                }
                ?>
            </div>
        </div>
    </div>

		<!-- Scripts -->
		<!-- end footer -->
		<!-- Javascript files-->
		<script src="../js/jquery.min.js"></script>
		<script src="../js/popper.min.js"></script>
		<script src="../js/bootstrap.bundle.min.js"></script>
		<script src="../js/jquery-3.0.0.min.js"></script>
		<script src="../js/plugin.js"></script>
		<!-- sidebar -->
		<script src="../js/jquery.mCustomScrollbar.concat.min.js"></script>
		<script src="../js/custom.js"></script>
	</body>
</html>
