<?php
require_once ("../lib/loader.php");
if(!isSignedIn("admin")){
    redirect("../");
    return;
}
global $activeUser;
$type = get("type");
?>
<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>

		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<!-- mobile metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="viewport" content="initial-scale=1, maximum-scale=1">
		<!-- site metas -->
		<title>system</title>
		<meta name="keywords" content="">
		<meta name="description" content="">
		<meta name="author" content="">
		<!-- bootstrap css -->
		<link rel="stylesheet" href="../css/bootstrap.min.css">
		<!-- style css -->
		<link rel="stylesheet" href="../css/style.css">
		<!-- Responsive-->
		<link rel="stylesheet" href="../css/responsive.css">
		<!-- fevicon -->
		<link rel="icon" href="../images/fevicon.png" type="image/gif" />
		<!-- Scrollbar Custom CSS -->
		<link rel="stylesheet" href="../css/jquery.mCustomScrollbar.min.css">
		<!-- Tweaks for older IEs-->
        <link href="../css/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
		<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
	</head>
    <body>

    <?php
        include ("header.php");
    ?>

    <?php

    switch ($type){
        case "load":
            ?>

            <div class="content">
                <div class="row">
                    <div class="col-12">
                        <a href="pharmacies-list.php" class="btn btn-danger full-width btn-lg"> رجوع </a>
                        <hr>
                        <h1 class="page-title"> عرض الصيدليات </h1>
                        <?php
                        $query = new MySQLQuery();
                        $query->select("pharmacy");
                        if(!$query->rows()){
                            getMessage("لا توجد بيانات");
                        }else{
                            ?>
                            <div class="table-responsive">
                            <table class="table ar table-bordered">
                            <tr>
                                <th>الاسم</th>
                                <th>الكود</th>
                                <th>عرض</th>
                                <th>حذف</th>
                            </tr>

                            <?php
                            foreach ($query->results() as $result){
                                ?>
                                <tr>
                                    <td><?= $result["name"] ?></td>
                                    <td><?= $result["code"] ?></td>
                                    <td>
                                        <a class="btn btn-success" href="pharmacy.php?id=<?= $result["id"]  ?>">
                                            <i class="fa fa-file"></i>
                                        </a>
                                    </td>
                                    <td>
                                        <a class="btn btn-danger" href="delete.php?type=pharmacy&id=<?= $result["id"]  ?>">
                                            <i class="fa fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php
                            }
                            ?>
                            </table>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                </div>
            </div>

            <?php
            break;

        case "add":
            ?>

            <div class="content">
                <div class="row">
                    <div class="col-12">
                        <a href="pharmacies-list.php" class="btn btn-danger full-width btn-lg"> رجوع </a>
                        <hr>
                        <h1 class="page-title">اضافة جديد</h1>
                        <?php
                            if(set("activate")){

                                if(empty(post("name")) || empty(post("code")) || empty(post("phone"))
                                    || empty(post("password")) || empty(post("password_confirm"))){
                                    getMessage("البيانات غير صحيحة");
                                }else{
                                    if(post("password") != post("password_confirm")){
                                        getMessage("كلمة السر غير متطابقة");
                                    }else{
                                        $query = new MySQLQuery();
                                        $query->sql("(SELECT `code` FROM `admin` WHERE `code` = ?) UNION" .
                                            " (SELECT `code` FROM `pharmacy` WHERE `code` = ?) UNION" .
                                            " (SELECT `code` FROM `customer` WHERE `code` = ?)");

                                        $query->values([post("code"), post("code"), post("code")]);

                                        if(!$query->execute()){
                                            getMessage("خطأ");
                                        }else{
                                            if($query->rows()){
                                                getMessage("الكود مسجل مسبقا");
                                            }else{
                                                $data = [
                                                        "name" => post("name"),
                                                        "code" => post("code"),
                                                        "phone" => post("phone"),
                                                        "password" => EncodingManager::password(post("password")),
                                                        "admin" => $activeUser["id"]
                                                    ];
                                                if(!$query->insert("pharmacy", $data)){
                                                    getMessage("خطأ");
                                                }else{
                                                    getMessage("تم التسجيل", "success");
                                                }

                                            }
                                        }

                                    }
                                }

                            }
                        ?>
                        <form method="post" action="" class="data-form">
                            <label>الاسم</label>
                            <input type="text" class="form-control" name="name">
                            <label>الكود</label>
                            <input type="text" class="form-control" name="code">
                            <label>رقم الهاتف</label>
                            <input type="text" class="form-control" name="phone">
                            <label>كلمة السر</label>
                            <input type="password" class="form-control" name="password">
                            <label>إعادة كلمة السر</label>
                            <input type="password" class="form-control" name="password_confirm">
                            <button class="btn" name="activate" type="submit">تسجيل</button>
                        </form>
                    </div>
                </div>
            </div>

            <?php
            break;

        default:
            ?>

            <div class="content">
                <div class="row">
                    <div class="col-12">
                        <a href="./" class="btn btn-danger full-width btn-lg"> رجوع </a>
                        <hr>
                        <h1 class="page-title">الصيدليات</h1>
                        <a href="pharmacies-list.php?type=load" class="btn btn-outline-danger full-width btn-lg"> عرض الصيدليات المسجلة </a>
                        <hr>
                        <a href="pharmacies-list.php?type=add" class="btn btn-outline-success full-width btn-lg"> اضافة صيدلية جديدة </a>
                    </div>
                </div>
            </div>

        <?php
    }

    ?>

		<!-- Scripts -->
		<!-- end footer -->
		<!-- Javascript files-->
		<script src="../js/jquery.min.js"></script>
		<script src="../js/popper.min.js"></script>
		<script src="../js/bootstrap.bundle.min.js"></script>
		<script src="../js/jquery-3.0.0.min.js"></script>
		<script src="../js/plugin.js"></script>
		<!-- sidebar -->
		<script src="../js/jquery.mCustomScrollbar.concat.min.js"></script>
		<script src="../js/custom.js"></script>
	</body>
</html>
