<?php 

class EncodingManager{
	
	// encoding private key
	public static $privateKey = "designy-code";
	
	public static function multiMD5($value){
		return md5( md5( md5( base64_encode( $value ) ) ) );
	}
	
	public static function password($password){
		
		$passArray = explode("/", $password);
		
		$newCharsArray = [];
		
		foreach($passArray as $char){
			$newCharsArray[] = ord($char) + 5;
		}
		
		$newPassword = "";
		
		foreach($newCharsArray as $char){
			$newPassword .= chr($char);
		}
		
		return self::multiMD5($newPassword);
		
	}
	
	public static function check($pass, $old){
		return $old == self::passwordEncrypt($pass);
	}
	
	public static function integerEncrypt($id){
		
		if(!is_numeric($id)) return "undefined";
		
		$keyCharsArray = str_split(self::$privateKey);
		
		$keyValidate = [];
		
		foreach($keyCharsArray as $character) $keyValidate[] = ord($character);
		
		$newId = $id + strtotime(date("Y"));
		
		foreach($keyValidate as $number) $newId += $number;
		
		$numbersArray = str_split($newId, 3);
		
		return implode("-", array_reverse($numbersArray));
		
	}
	
	public static function integerDecrypt($id){
		
		$idRev = array_reverse(explode("-", $id)); 
		
		$keyCharsArray = str_split(self::$privateKey);
		
		$keyValidate = [];
		
		foreach($keyCharsArray as $character) $keyValidate[] = ord($character);
		
		$newId = (int) implode("", $idRev) - strtotime(date("Y"));
		
		foreach($keyValidate as $number) $newId -= $number;
		
		return $newId;
		
	}
	
	public static function stringEncode($str){
		
		$charactersArray = str_split($str);
		$keyCharsArray   = str_split(self::$privateKey);
		
		$newWord     = [];
		$keyValidate = [];
		
		foreach($keyCharsArray as $character) $keyValidate[] = ord($character);
		
		$serial = [];
		
		for($i = 0, $x = 0; $i < count($charactersArray); $i++, $x++){
			if($x == count($keyCharsArray)) $x = 0;
			$serial[] = intval($keyValidate[$x] + (($i + 1) * self::exDouble($i + $x)));
		}
		
		foreach($charactersArray as $character) $newWord[] = ord($character);
		
		$finalCharsFormat = [];
		
		for($i = 0; $i < count($charactersArray); $i++) 
			$finalCharsFormat[] = $newWord[$i] + $serial[$i];
		
		$finalCharsFormat = array_reverse($finalCharsFormat);
		
		return implode("/", $finalCharsFormat);
		
	}
	
	public static function stringDecode($str){
		
		$strRev = explode("/", $str); 
		$charactersArray = array_reverse($strRev);
		
		$keyCharsArray = str_split(self::$privateKey);
		
		$keyValidate = [];
		
		foreach($keyCharsArray as $character) $keyValidate[] = ord($character);
		
		$serial = [];
		
		for($i = 0, $x = 0; $i < count($charactersArray); $i++, $x++){
			if($x == count($keyCharsArray)) $x = 0;
			$serial[] = intval($keyValidate[$x] + (($i + 1) * self::exDouble($i + $x)));
		}
		
		$finalCharsFormat = [];
		
		for($i = 0; $i < count($charactersArray); $i++)
			$finalCharsFormat[] = intval($charactersArray[$i]) - intval($serial[$i]);
		
		$cleanString = [];
		
		foreach($finalCharsFormat as $character) $cleanString[] = chr($character);
		
		return implode("", $cleanString);
		
	}
	
	private static function exDouble($dble){
		return $dble != 0 ? $dble * ($dble / $dble) * ($dble * $dble) : 1;
	}
	
}