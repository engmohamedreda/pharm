<?php
require_once ("../lib/loader.php");
if(!isSignedIn("customer")){
    redirect("../");
    return;
}

global $activeUser;

if(!set("id")){
    redirect("./");
    return;
}

$id = get("id");

if(!set("remedy")){
    redirect("./");
    return;
}

$remedy = get("remedy");

if(!set("lat")){
    redirect("./");
    return;
}

$lat = get("lat");

if(!set("lng")){
    redirect("./");
    return;
}

$lng = get("lng");
$return = false;

if(set("activate") && get("activate") == "yes"){
    $query = new MySQLQuery();
    $query->where(["customer" => $activeUser["id"], "remedy" => $remedy, "pharmacy" => $id, "status" => 0]);
    $query->select("request");
    if($query->rows()){
        $message = ["الطلب مرسل مسبقا"];
        $return = true;
    }else{
        if($query->insert("request", [
                "customer" => $activeUser["id"], "remedy" => $remedy, "pharmacy" => $id, "date" => date("Y-m-d"), "lat" => $lat, "lng" => $lng
        ])){
            $message = ["تم ارسال الطلب", "success"];
            $return = true;
        }else{
            $message = ["خطأ"];
            $return = true;
        }
    }
}

?>
<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>

		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<!-- mobile metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="viewport" content="initial-scale=1, maximum-scale=1">
		<!-- site metas -->
		<title>system</title>
		<meta name="keywords" content="">
		<meta name="description" content="">
		<meta name="author" content="">
		<!-- bootstrap css -->
		<link rel="stylesheet" href="../css/bootstrap.min.css">
		<!-- style css -->
		<link rel="stylesheet" href="../css/style.css">
		<!-- Responsive-->
		<link rel="stylesheet" href="../css/responsive.css">
		<!-- fevicon -->
		<link rel="icon" href="../images/fevicon.png" type="image/gif" />
		<!-- Scrollbar Custom CSS -->
		<link rel="stylesheet" href="../css/jquery.mCustomScrollbar.min.css">
		<!-- Tweaks for older IEs-->
        <link href="../css/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
		<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
	</head>
    <body>

        <div class="content">
            <div class="row">
                <div class="col-12">
                    <h1 class="page-title">تاكيد</h1>
                </div>
                <?php
                if($return){
                ?>
                <div class="col-12">
                    <?= (isset($message[1]) ? getMessage($message[0], $message[1]) : getMessage($message[0])); ?>
                    <a href="remedy.php?id=<?= $remedy ?>" class="btn btn-success full-width btn-lg"> رجوع </a>
                </div>
                <?php
                }else{
                ?>
                <div class="col-6">
                    <a href="activate.php?id=<?= $id ?>&remedy=<?= $remedy ?>&lat=<?= $lat ?>&lng=<?= $lng ?>&activate=yes"
                       class="btn btn-success full-width btn-lg"> نعم </a>
                </div>
                <div class="col-6">
                    <a href="pharmacy.php?id=<?= $id ?>&remedy=<?= $remedy ?>&client-lat=<?= $lat ?>&client-lng=<?= $lng ?>" class="btn btn-danger full-width btn-lg">لا</a>
                </div>
                <?php
                }
                ?>
            </div>
        </div>

		<!-- Scripts -->
		<!-- end footer -->
		<!-- Javascript files-->
		<script src="../js/jquery.min.js"></script>
		<script src="../js/popper.min.js"></script>
		<script src="../js/bootstrap.bundle.min.js"></script>
		<script src="../js/jquery-3.0.0.min.js"></script>
		<script src="../js/plugin.js"></script>
		<!-- sidebar -->
		<script src="../js/jquery.mCustomScrollbar.concat.min.js"></script>
		<script src="../js/custom.js"></script>
	</body>
</html>
