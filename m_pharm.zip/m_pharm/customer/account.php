<?php
require_once ("../lib/loader.php");
if(!isSignedIn("customer")){
    redirect("../");
    return;
}
global $activeUser;
$current = $activeUser;

?>
<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>

		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<!-- mobile metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="viewport" content="initial-scale=1, maximum-scale=1">
		<!-- site metas -->
		<title>system</title>
		<meta name="keywords" content="">
		<meta name="description" content="">
		<meta name="author" content="">
		<!-- bootstrap css -->
		<link rel="stylesheet" href="../css/bootstrap.min.css">
		<!-- style css -->
		<link rel="stylesheet" href="../css/style.css">
		<!-- Responsive-->
		<link rel="stylesheet" href="../css/responsive.css">
		<!-- fevicon -->
		<link rel="icon" href="../images/fevicon.png" type="image/gif" />
		<!-- Scrollbar Custom CSS -->
		<link rel="stylesheet" href="../css/jquery.mCustomScrollbar.min.css">
		<!-- Tweaks for older IEs-->
        <link href="../css/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
		<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
	</head>
    <body>

        <?php
            include ("header.php");
        ?>

        <div class="content">
            <div class="row">
                <div class="col-12">
                    <a href="./" class="btn btn-danger full-width btn-lg"> رجوع </a>
                    <hr>
                    <h1 class="page-title"> تعديل البيانات الشخصية </h1>
                    <?php
                    if(set("activate")){

                        if(empty(post("name")) || empty(post("code")) || empty(post("phone"))){
                            getMessage("البيانات غير صحيحة");
                        }else{
                            $passwordUpdate = false;

                            if(!empty("password")){
                                if(post("password") != post("password_confirm")){
                                    getMessage("كلمة السر غير متطابقة");
                                }else $passwordUpdate = true;
                            }

                            $query = new MySQLQuery();
                            $query->sql("(SELECT `code` FROM `admin` WHERE `code` = ?) UNION" .
                                " (SELECT `code` FROM `customer` WHERE `code` = ? AND `id` <> ?) UNION" .
                                " (SELECT `code` FROM `pharmacy` WHERE `code` = ?)");

                            $query->values([post("code"), post("code"), $current["id"], post("code")]);

                            if(!$query->execute()){
                                getMessage("خطأ");
                            }else{
                                if($query->rows()){
                                    getMessage("الكود مسجل مسبقا");
                                }else{

                                    $data = [
                                        "name" => post("name"),
                                        "phone" => post("phone"),
                                        "code" => post("code")
                                    ];

                                    if($passwordUpdate){
                                        $data["password"] = EncodingManager::password(post("password"));
                                    }

                                    $query->where(["id" => $current["id"]]);

                                    if(!$query->update("customer", $data)){
                                        getMessage("خطأ");
                                    }else{
                                        getMessage("تم التعديل", "success");
                                        $query->where(["id" => $current["id"]]);
                                        if(!$query->select("customer")) getMessage("خطأ");
                                        $current = $query->results()[0];
                                    }
                                }
                            }
                        }
                    }
                    ?>
                    <form method="post" action="" class="data-form">
                        <label>الاسم</label>
                        <input type="text" class="form-control" name="name" value="<?= $current["name"] ?>">
                        <label>الكود</label>
                        <input type="text" class="form-control" name="code" value="<?= $current["code"] ?>">
                        <label>رقم الهاتف</label>
                        <input type="text" class="form-control" name="phone" value="<?= $current["phone"] ?>">
                        <label>كلمة السر</label>
                        <input type="password" class="form-control" name="password">
                        <label>إعادة كلمة السر</label>
                        <input type="password" class="form-control" name="password_confirm">
                        <button class="btn" name="activate" type="submit">تعديل</button>
                    </form>
                </div>
            </div>
        </div>

		<!-- Scripts -->
		<!-- end footer -->
		<!-- Javascript files-->
		<script src="../js/jquery.min.js"></script>
		<script src="../js/popper.min.js"></script>
		<script src="../js/bootstrap.bundle.min.js"></script>
		<script src="../js/jquery-3.0.0.min.js"></script>
		<script src="../js/plugin.js"></script>
		<!-- sidebar -->
		<script src="../js/jquery.mCustomScrollbar.concat.min.js"></script>
		<script src="../js/custom.js"></script>
	</body>
</html>
