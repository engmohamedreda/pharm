<?php

/*/*************************************************
* @author  : Abdelwahab Taha (eng.abdelwahab.taha@gmail.com)
* @version : 1.0
* @since   : PHP 5.6
*************************************************
/*/

/**
* Host name
* for example : 
* 	mysql -> localhost
* 	microsoft sql server -> localhost:1433 (hostname : port number)
* 	sqlite -> 
*		1- if you already have the database file copy your file in (system directory \\lib\\database\\dbFiles)
*		2- define DATABASE with your file name or enter the new database name
*/
define("DB_SERVER","localhost");

/**
* Database type
* supported databases:
*	1- mysql -> MySQL
*	2- microsoft sql server -> MSSQL
*	3- sqlite -> SQLITE
*/
define("DB_TYPE","MySQL");

/**
* Database name
*/
define("DATABASE","m_pharmacies");

/**
* Database username
*/
define("DB_SERVER_USERNAME","root");

/**
* Database password
*/
define("DB_SERVER_PASSWORD","");

/**
* site domain
*/
define("LINK","");

/**
* local timezone
*/
define("TIMEZONE","Africa/Cairo");