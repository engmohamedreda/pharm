<?php

$array = ["error" => false, "message" => null, "data" => []];

require_once("../lib/loader.php");

if(!isset($_COOKIE["PHPSESSID"])){
    $array = ["error" => true, "message" => "access denied"];
    echo json_encode($array);
    return;
}

if(!set("id")){
    $array = ["error" => true, "message" => "not found"];
    echo json_encode($array);
    return;
}

$query = new MySQLQuery();
$query->sql("SELECT * FROM `pharmacy` WHERE `id` IN (SELECT `pharmacy` FROM `pharmacy_remedy` WHERE `remedy` = ?)");

$query->value(post("id"));

$query->execute();

$array["message"] = "success";
$array["data"]    = $query->results("ASSOC");
$array["error"]   = false;

echo json_encode($array);
