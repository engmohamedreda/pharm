<?php
require_once ("../lib/loader.php");
if(!isSignedIn("customer")){
    redirect("../");
    return;
}
global $activeUser;

$id = get("id");
$query = new MySQLQuery();

$query->where(["id" => $id]);

if(!$query->select("request")){
    redirect("./");
    return;
}
if($query->rows() != 1){
    redirect("./");
    return;
}

$current = $query->results()[0];

if(!$current["customer"] == $activeUser["id"]){
    redirect("./");
    return;
}

$customer = $activeUser;
$query->where(["id" => $current["pharmacy"]]);
$query->select("pharmacy");
$pharmacy = $query->results()[0];
$query->where(["id" => $current["remedy"]]);
$query->select("remedy");
$remedy = $query->results()[0];
?>
<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>

		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<!-- mobile metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="viewport" content="initial-scale=1, maximum-scale=1">
		<!-- site metas -->
		<title>system</title>
		<meta name="keywords" content="">
		<meta name="description" content="">
		<meta name="author" content="">
		<!-- bootstrap css -->
		<link rel="stylesheet" href="../css/bootstrap.min.css">
		<!-- style css -->
		<link rel="stylesheet" href="../css/style.css">
		<!-- Responsive-->
		<link rel="stylesheet" href="../css/responsive.css">
		<!-- fevicon -->
		<link rel="icon" href="../images/fevicon.png" type="image/gif" />
		<!-- Scrollbar Custom CSS -->
		<link rel="stylesheet" href="../css/jquery.mCustomScrollbar.min.css">
		<!-- Tweaks for older IEs-->
        <link href="../css/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
		<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
	</head>
    <body>

        <?php
            include ("header.php");
        ?>

        <div class="content">
            <div class="row">
                <div class="col-12">
                    <a href="requests-list.php?type=<?= $current["status"] ? "done" : "accept" ?>" class="btn btn-danger full-width btn-lg"> رجوع </a>
                    <hr>
                    <h1 class="page-title"> <?= $current["id"] ?> </h1>
                    <div class="table-responsive">
                        <table class="table ar table-bordered">
                            <tr>
                                <th>العميل</th>
                                <th><?= $customer["name"] ?></th>
                            </tr>
                            <tr>
                                <th>رقم البطاقة التامينية</th>
                                <th><?= $customer["code"] ?></th>
                            </tr>
                            <tr>
                                <th>رقم الهاتف</th>
                                <th><?= $customer["phone"] ?></th>
                            </tr>
                            <tr>
                                <th>الصيدلية</th>
                                <th><?= $pharmacy["name"] ?></th>
                            </tr>
                            <tr>
                                <th>كود الصيدلية</th>
                                <th><?= $pharmacy["code"] ?></th>
                            </tr>
                            <tr>
                                <th>رقم هاتف الصيدلية</th>
                                <th><?= $pharmacy["phone"] ?></th>
                            </tr>
                            <tr>
                                <th>الدواء</th>
                                <th><?= $remedy["name"] ?></th>
                            </tr>
                            <tr>
                                <th>التاريخ</th>
                                <th><?= $current["date"] ?></th>
                            </tr>
                            <?php
                            if($current["status"]){
                                ?>
                                <tr>
                                    <th>الحالة</th>
                                    <th>تم التسليم للعميل</th>
                                </tr>
                                <tr>
                                    <th>التقييم</th>
                                    <th>
                                        <?php
                                        if($current["rate"] == 1){
                                            echo "<span>خدمة سيئة</span>";
                                        }else if ($current["rate"] == 2){
                                            echo "<span>خدمة ضعيفة</span>";
                                        }else if ($current["rate"] == 3){
                                            echo "<span>خدمة جيدة الى حد ما</span>";
                                        }else if ($current["rate"] == 4){
                                            echo "<span>خدمة جيدة</span>";
                                        }else if ($current["rate"] == 5){
                                            echo "<span>خدمة ممتازة</span>";
                                        }
                                        ?>
                                    </th>
                                </tr>
                                <?php
                            }else{
                                ?>
                                <tr>
                                    <th>الحالة</th>
                                    <th>فى انتظار التسليم للعميل</th>
                                </tr>
                                <?php
                            }
                            ?>
                        </table>
                    </div>
                </div>
                <?php
                if(!$current["status"]) {
                    ?>
                    <div class="col-12">
                        <h1 class="page-title">تاكيد الاستلام</h1>
                        <?php
                        if (set("activate")) {

                            if (empty(post("rate")) || !is_numeric(post("rate")) || !in_array(post("rate"), [1, 2, 3, 4, 5])) {
                                getMessage("البيانات غير صحيحة");
                            } else {
                                $data = [
                                    "rate" => post("rate"),
                                    "status" => 1
                                ];
                                $query->where(["id" => $current["id"]]);
                                if (!$query->update("request", $data)) {
                                    getMessage("خطأ");
                                } else {
                                    getMessage("تم التاكيد", "success");
                                    redirect("request.php?id=" . get("id"));
                                }

                            }
                        }
                        ?>
                        <form method="post" action="" class="data-form">
                            <label>التقييم</label>
                            <select type="text" class="form-control" name="rate">
                                <option>حدد</option>
                                <option value="1">خدمة سيئة</option>
                                <option value="2">خدمة ضعيفة</option>
                                <option value="3">خدمة جيدة الى حد ما</option>
                                <option value="4">خدمة جيدة</option>
                                <option value="5">خدمة ممتازة</option>
                            </select>
                            <button class="btn" name="activate" type="submit">تاكيد الاستلام</button>
                        </form>
                    </div>
                    <?php
                }
                ?>
            </div>
        </div>

		<!-- Scripts -->
		<!-- end footer -->
		<!-- Javascript files-->
		<script src="../js/jquery.min.js"></script>
		<script src="../js/popper.min.js"></script>
		<script src="../js/bootstrap.bundle.min.js"></script>
		<script src="../js/jquery-3.0.0.min.js"></script>
		<script src="../js/plugin.js"></script>
		<!-- sidebar -->
		<script src="../js/jquery.mCustomScrollbar.concat.min.js"></script>
		<script src="../js/custom.js"></script>
	</body>
</html>
