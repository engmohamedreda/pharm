<?php

$activeUser = null;

function isSignedIn($type){
    global $activeUser;
    switch ($type){
        case "admin":
            $key = get_cookie($type);
            if($key === false){
                return false;
            }
            $query = new MySQLQuery();
            $query->where(["id" => $key["value"]]);
            if(!$query->select("admin")){
                getMessage($query->error());
                return false;
            }
            if($query->rows() != 1){
                unset_cookies("admin");
                return false;
            }
            $activeUser = $query->results()[0];
            break;
        case "pharmacy":
            $key = get_cookie($type);
            if($key === false){
                return false;
            }
            $query = new MySQLQuery();
            $query->where(["id" => $key["value"]]);
            if(!$query->select("pharmacy")){
                getMessage($query->error());
                return false;
            }
            if($query->rows() != 1){
                unset_cookies("pharmacy");
                return false;
            }
            $activeUser = $query->results()[0];
            break;
        case "customer":
            $key = get_cookie($type);
            if($key === false){
                return false;
            }
            $query = new MySQLQuery();
            $query->where(["id" => $key["value"]]);
            if(!$query->select("customer")){
                getMessage($query->error());
                return false;
            }
            if($query->rows() != 1){
                unset_cookies("customer");
                return false;
            }
            $activeUser = $query->results()[0];
            break;
        default:
            return false;
    }

    return true;

}

function signIn($email, $password){

    if(empty($email)){
        getMessage("الكود غير صحيح");
        return false;
    }

    $password = EncodingManager::password($password);

    $where = ["code" => $email, "password" => $password];

    $query = new MySQLQuery();

    $query->where($where);
    if(!$query->select("admin")){
        getMessage($query->error() . $query->sql());
        return false;
    }
    if($query->rows() == 1){
        $result = $query->results()[0];
        set_cookie("admin", $result["id"]);
        redirect("admin/");
        return true;
    }

    $query->where($where);
    if(!$query->select("pharmacy")){
        getMessage($query->error() . $query->sql());
        return false;
    }
    if($query->rows() == 1){
        $result = $query->results()[0];
        set_cookie("pharmacy", $result["id"]);
        redirect("pharmacy/");
        return true;
    }

    $query->where($where);
    if(!$query->select("customer")){
        getMessage($query->error());
        return false;
    }
    if($query->rows() == 1){
        $result = $query->results()[0];
        set_cookie("customer", $result["id"]);
        redirect("customer/");
        return true;
    }

    getMessage("المستخدم غير مسجل");
    return false;

}
