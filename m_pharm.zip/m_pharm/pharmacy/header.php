
<header>
    <div class="header-top">
        <div class="header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                        <div class="full">
                            <div class="center-desk">
                                <div class="logo">
                                    <a href="./"><img src="../images/logo.png" style="height: 80px !important; width: auto;" alt="#" /></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                        <div class="menu-area">
                            <div class="limit-box">
                                <nav class="main-menu">
                                    <ul class="menu-area-main">
                                        <li class="active">
                                        <li>
                                            <a href="./">
                                                <i class="fa fa-list-alt"></i>
                                                القائمة
                                            </a>
                                        </li>
                                        <li>
                                            <a href="remedies-list.php">
                                                <i class="fa fa-search"></i>
                                                الادوية المسجلة
                                            </a>
                                        </li>
                                        <li>
                                            <a href="requests-list.php">
                                                <i class="fa fa-archive"></i>
                                                طلبات الادوية
                                            </a>
                                        </li>
                                        <li>
                                            <a href="account.php">
                                                <i class="fa fa-user-o"></i>
                                                إدارة البيانات الشخصية
                                            </a>
                                        </li>
                                        <li>
                                            <a href="log-out.php">
                                                <i class="fa fa-close"></i>
                                                تسجيل خروج
                                            </a>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0)" onclick="powerSystem.close()">
                                                <i class="fa fa-power-off"></i>
                                                خروج من التطبيق
                                            </a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- end header inner -->
    </div>
</header>